#include "graph.h"
#include "parallel.h"

std::pair<intT*,intT> mst(wghEdgeArray<intT> E);

