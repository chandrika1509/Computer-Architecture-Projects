#include "graph.h"

pair<intT,intT> BFS(intT start, graph<intT> G);
