#!/bin/bash
make all
for run in {1..5}
do
  taskset 0x01 ./linearread 32
  taskset 0x01 ./linearwrite 32
  taskset 0x01 ./randomread
  taskset 0x01 ./randomwrite 
done
