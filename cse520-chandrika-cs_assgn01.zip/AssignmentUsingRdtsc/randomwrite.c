
#define _GNU_SOURCE
#include <stdlib.h>
#include <stdio.h>
#include <sys/time.h>
#include "rdtsc.h"
#include <unistd.h>
#include <stdint.h>
#include <string.h>
#include <sched.h>
struct Node {
	int data;
	struct Node* nextNode;
};
#define MINBYTES (1 << 10)  /* Working set size ranges from 1 KB */
#define MAXBYTES (1 << 27)  /* ... up to 128 MB */
#define MAXSTRIDE 64        /* Strides range from 1 to 32 */
#define STRIDESTRIDE 2      /* increment stride by this amount each time */
#define MAXELEMS MAXBYTES/sizeof(struct Node)
unsigned long long test(int elems, struct Node* temp);
struct Node array_of_structures[MAXELEMS]; //The array we will be traversing


void init_data(struct Node* head, struct Node* tail, int n){
	int i=0;
	for( i=0; i<n ; i++){
		if (i ==0) {
			head= malloc(sizeof(struct Node));
			head->data = 1;
			head->nextNode = NULL;
			tail = head;

		}
		else {
			struct Node* tail_next_next = malloc(sizeof(struct Node));
			tail_next_next->data = 1;
			tail->nextNode =tail_next_next;
			array_of_structures[i] = *tail;
			tail = tail_next_next;
		}
		tail->nextNode = NULL;
	}
}


int main()
{
	int size;        /* Working set size (in bytes) */
	struct Node head, tail;
	init_data(&head, &tail, MAXELEMS);
	FILE *f;
	f = fopen("randomwrite.log", "a+"); // Logging to randomread.log file
	if (f == NULL) {
		printf("Unable to create a log file");
	}

	struct timezone tz;
	struct timeval tvstart, tvstop;
	unsigned long long int cycles[2];
	unsigned long microseconds;
	long double cal_freq_run_time;
	memset(&tz, 0, sizeof(tz));
	gettimeofday(&tvstart, &tz);
	cycles[0] = rdtsc();
	gettimeofday(&tvstart, &tz);
	usleep(250000);
	gettimeofday(&tvstop, &tz);
	cycles[1] = rdtsc();
	gettimeofday(&tvstop, &tz);
	microseconds = ((tvstop.tv_sec-tvstart.tv_sec)*1000000) + (tvstop.tv_usec-tvstart.tv_usec);
	cal_freq_run_time = (long double) (cycles[1]-cycles[0]) / microseconds;


	printf("\n Clock frequency is approx. %Lf MHz\n \n", cal_freq_run_time);
	fprintf(f, " \n Clock frequency is approx. %Lf MHz\n", cal_freq_run_time);
	printf("\t");
	fprintf(f,"\t");

	printf("\n");
	fprintf(f, "\n");

	printf("----------------RANDOM WRITE-----------------------\n\n");
	for (size = MAXBYTES; size >= MINBYTES; size >>= 1) {

		if (size > (1 << 20))
			printf("%dm\t", size / (1 << 20));
		else
			printf("%dk\t", size / 1024);

		unsigned long long elems = size/sizeof(struct Node);
		unsigned long long cycles = test(elems, &head);
		long double accessTime = (cycles*1000)/(cal_freq_run_time);
		long double access_time_per_element = accessTime/elems;
		printf("%Lf\t", access_time_per_element);
		printf("\n");

	}
	exit(0);
}

unsigned long long test(int elems, struct Node* temp) /* The test function */
{
	unsigned long long start_ticks, end_ticks;
	int count=0, i;
	start_ticks = rdtsc();
	for(count=0 ; count< elems;count++ ) {
		i = rand()%elems;
		array_of_structures[i].data = 0;
	}
	end_ticks = rdtsc();
	return end_ticks-start_ticks;
}


