AUTHOR : C.S.CHANDRIKA
ASU ID : 1215321133

The following are the instructions to run the program. 

1)In order to run the program, open the terminal in the folder and Type "sudo bash ./script". 

2) There is a bash script file, that runs these programs five times. The reason being, these values are written to the console to show the pattern of values . Note that all the four programs will run five times upon running the bashscript. You may change the number for your convenience. 

3)Makefile present in the folder consists of the commands needed to compile linearread.c, linearwrite.c, randomread.c and randomwrite.c . 
They do the functionality as represented by their respective names. 

4)The linearread and linearwrite take stride as the input argument. Currently , a value of 32 is given as an input to the program in the bashscript .You may change it to any value as per your preference. 

5) Upon executing the bashscript, you will realise that the programs are compiled and executed five times with the values being written to the console.

6) The values that are plotted in the report have been averaged i.e. the average of the readings have been plotted which we have got on running the program multiple times. 

7) The report presents a detailed analysis and plots.

8) taskset 0x01 enables it to run on a single core processor : core 0

