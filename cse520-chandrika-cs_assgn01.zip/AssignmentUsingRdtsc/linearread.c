
#define _GNU_SOURCE
#include <stdlib.h>
#include <stdio.h>
#include "clock.h"
#include "rdtsc.h"
#define MINBYTES (1 << 10)  /* Working set size ranges from 1 KB */
#define MAXBYTES (1 << 27)  /* ... up to 128 MB */
#define MAXSTRIDE 64        /* Strides range from 1 to 32 */
#define STRIDESTRIDE 2      /* increment stride by a factor of this amount each time */
#define MAXELEMS MAXBYTES/sizeof(int)
#include <sys/time.h>
#include <unistd.h>
#include <stdint.h>
#include <string.h>
#include <sched.h>



int data[MAXELEMS];
void initialise_data(int *data, int n);
unsigned long long test(int elems, int stride);


int main(int argc, char* argv[]) {        /* Working set size (in bytes) */
	int stride_from_user = atoi(argv[1]); /* Stride (in array elements) */
	initialise_data(data, MAXELEMS); /* Initialize each element in data to 1 */

	printf("\t");
	FILE *f;
	f = fopen("linearread.log", "a+"); // a+ (create + append) option will allow appending which is useful in a log file
	if (f == NULL) {
		printf("Something is wrong while opening log file \n");
	}

	struct timezone tz;
	struct timeval tvstart, tvstop;
	unsigned long long int cycles[2];
	unsigned long microseconds;
	long double cal_freq_run_time;
	memset(&tz, 0, sizeof(tz));
	gettimeofday(&tvstart, &tz);
	cycles[0] = rdtsc();
	gettimeofday(&tvstart, &tz);
	usleep(250000);
	gettimeofday(&tvstop, &tz);
	cycles[1] = rdtsc();
	gettimeofday(&tvstop, &tz);
	microseconds = ((tvstop.tv_sec-tvstart.tv_sec)*1000000) + (tvstop.tv_usec-tvstart.tv_usec);
	cal_freq_run_time = (long double) (cycles[1]-cycles[0]) / microseconds;



	printf("\n Clock frequency is approx. %Lf MHz\n \n", cal_freq_run_time);
	//	fprintf(f, " \n Clock frequency is approx. %.1f MHz\n", Mhz);
	printf("\t");
	//fprintf(f,"\t");
	printf("----------------LINEAR READ-----------------------\n \n");
	int stride = stride_from_user;
	for (stride = stride_from_user; stride <= MAXSTRIDE; stride *= STRIDESTRIDE)
		printf("\ts%d\t\t", stride);
	printf("\n");

	//test(MAXELEMS, stride_from_user);
	int size =0;
	for (size = MAXBYTES; size >= MINBYTES; size >>= 1) {
		int elems = size/sizeof(int);
		if (size > (1 << 20))
			printf("%dm\t", size / (1 << 20));
		else
			printf("%dk\t", size / 1024);

		for (stride = stride_from_user; stride <= MAXSTRIDE; stride *= STRIDESTRIDE) {
			unsigned long long cycles = test(elems, stride);
			long double ratio = size/stride;
			long double accessTime = (cycles*1000)/(cal_freq_run_time);
			long double access_time_per_element = accessTime/ratio;
			printf("%Lf\t", access_time_per_element);
		}
		printf("\n");
	}
	exit(0);
}


void initialise_data(int *data, int n)
{
	int i;

	for (i = 0; i < n; i++)
		data[i] = 1;
}

unsigned long long test(int elems, int stride) /* The test function */
{
	unsigned long long start_ticks, end_ticks;
	int i, result = 0;
	volatile int sink;
	start_ticks = rdtsc();
	for(i=elems;i >0; i -= stride) {
		result += data[i];
	}
	sink = result; /* So compiler doesn't optimize away the loop */
	end_ticks = rdtsc();
	i = sink;
	return end_ticks-start_ticks;
}


