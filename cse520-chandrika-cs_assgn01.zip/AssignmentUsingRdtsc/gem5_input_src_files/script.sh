#!/bin/bash
make all
for run in {1..5}
do
  /home/chandrika/gem5/build/X86/gem5.opt configs/example/se.py -c /home/chandrika/workspace/AssignmentUsingRdtsc/gem5_input_src_files/linearread --options=128,32
  /home/chandrika/gem5/build/X86/gem5.opt configs/example/se.py -c /home/chandrika/workspace/AssignmentUsingRdtsc/gem5_input_src_files/linearwrite -options=128,32
  /home/chandrika/gem5/build/X86/gem5.opt configs/example/se.py -c /home/chandrika/workspace/AssignmentUsingRdtsc/gem5_input_src_files/randomread -options=128,32
  /home/chandrika/gem5/build/X86/gem5.opt configs/example/se.py -c /home/chandrika/workspace/AssignmentUsingRdtsc/gem5_input_src_files/randomwrite -options=128,32
done
