AUTHOR : C.S.CHANDRIKA
ASU ID : 1215321133

The following are the instructions to run the program.

THESE ARE THE FILES MEANT FOR RUNNING ON GEM5 SIMULATOR 

Following is the way to run the Gem5 tool
Run the program using the following command of "./build/X86/gem5.opt configs/example/se.py -c /home/chandrika/workspace/AssignmentUsingRdtsc/gem5_input_src_files/linearread -options=128,32" for a size, stride of 128,32. 
and 
Comment the for loop of size increments, and again take the readings in gem5 with the above command again . 
Subtracting the two readings with each other, gives the output.

Kindly modify as per instructions to do the simulations.


Repeat this for all the linearread, linearwrite, randomread and randomwrite applications.

Kindly refer the official Gem5 document shared by the professor.

1)In order to run the program, open the terminal in the folder and Type "sudo bash ./script" or "sudo bash ./script_making.sh"

3)Makefile present in the folder consists of the commands needed to compile linearread.c, linearwrite.c, randomread.c and randomwrite.c . 
They do the functionality as represented by their respective names. 

4)The linearread and linearwrite take both size and stride as the input argument. Currently , a value of 128 elements and a stride of 32 is given as an input to the program in the bashscript .You may change it to any value as per your preference to run with GEM 5 .

NOTE THAT FOR LINEAR READ AND LINEAR WRITE : SIZE AND STRIDE are given
but for RANDOM READ AND RANDOM WRITE : STRIDE doesn't matter 

5) Upon executing the bashscript, you will realise that the programs are compiled and executed five times with the values being written to the console.

6) The values that are plotted in the report have been averaged i.e. the average of the readings have been plotted which we have got on running the program multiple times. 

7) The report presents a detailed analysis and plots.

8) taskset 0x01 enables it to run on a single core processor : core 0

NOTE: Kindly run the same program in the normal folder named "Assignment" incase you find difficulty using these programs in gem5 folder.








