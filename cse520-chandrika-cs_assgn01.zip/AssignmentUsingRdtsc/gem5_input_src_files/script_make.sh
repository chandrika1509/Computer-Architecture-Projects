#!/bin/bash
make all
do
  taskset 0x01 ./linearread 128 32
  taskset 0x01 ./linearwrite 128 32
  taskset 0x01 ./randomread 128
  taskset 0x01 ./randomwrite 128
done
