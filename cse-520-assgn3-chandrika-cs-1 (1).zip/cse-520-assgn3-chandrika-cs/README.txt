Steps for Assignment 3 
Author : C.S.Chandrika 
ASU ID : 1215321133. 
---------------------------------
1. Firstly apply the patch to your un-modified Gem5 simulator code base. 
2. Build the entire gem5 codebase using the command "scons -j4 build/X86/gem5.opt"
3. Now , in order to run the simulations for the various Branch Prediction Policies , type in the following commands. 
4. Now you can see these values tabulated in the project report.

------------------------------------------------------------------------------------------------------------------------------------
2-BIT LOCAL BP POLICY

1) For 8KB Configuration , we have a mapping for LocalBP8KB Policy :

(i) We have three inputs of BFS, MST and Queens.

./build/X86/gem5.opt configs/example/se.py --cpu-type=DerivO3CPU --caches --l2cache --bp-type=LocalBP8KB -c /media/chandrika/LinuxStorage/Inputs_for_branch_pred/benchmark/bin/BFS_opt -o "/media/chandrika/LinuxStorage/Inputs_for_branch_pred/benchmark/inputs/R10k.graph"

./build/X86/gem5.opt configs/example/se.py --cpu-type=DerivO3CPU --caches --l2cache --bp-type=LocalBP8KB -c /media/chandrika/LinuxStorage/Inputs_for_branch_pred/benchmark/bin/MST_opt -o "/media/chandrika/LinuxStorage/Inputs_for_branch_pred/benchmark/inputs/rand-weighted-small.graph"

./build/X86/gem5.opt configs/example/se.py --cpu-type=DerivO3CPU --caches --l2cache --bp-type=LocalBP8KB -c /media/chandrika/LinuxStorage/Inputs_for_branch_pred/benchmark/bin/queens_opt -o "-c 11"

2) For 32KB Configuration

./build/X86/gem5.opt configs/example/se.py --cpu-type=DerivO3CPU --caches --l2cache --bp-type=LocalBP32KB -c /media/chandrika/LinuxStorage/Inputs_for_branch_pred/benchmark/bin/BFS_opt -o "/media/chandrika/LinuxStorage/Inputs_for_branch_pred/benchmark/inputs/R10k.graph"

./build/X86/gem5.opt configs/example/se.py --cpu-type=DerivO3CPU --caches --l2cache --bp-type=LocalBP32KB -c /media/chandrika/LinuxStorage/Inputs_for_branch_pred/benchmark/bin/MST_opt -o "/media/chandrika/LinuxStorage/Inputs_for_branch_pred/benchmark/inputs/rand-weighted-small.graph"

./build/X86/gem5.opt configs/example/se.py --cpu-type=DerivO3CPU --caches --l2cache --bp-type=LocalBP32KB -c /media/chandrika/LinuxStorage/Inputs_for_branch_pred/benchmark/bin/queens_opt -o "-c 11"

----------------------------------------------------------------------------------------------------------------------------------------
TOURNAMENT BRANCH PREDICTOR 

1) For 8KB Configuration
(i) We have three inputs of BFS, MST and Queens.

./build/X86/gem5.opt configs/example/se.py --cpu-type=DerivO3CPU --caches --l2cache --bp-type=TournamentBP8KB -c /media/chandrika/LinuxStorage/Inputs_for_branch_pred/benchmark/bin/BFS_opt -o "/media/chandrika/LinuxStorage/Inputs_for_branch_pred/benchmark/inputs/R10k.graph"

./build/X86/gem5.opt configs/example/se.py --cpu-type=DerivO3CPU --caches --l2cache --bp-type=TournamentBP8KB -c /media/chandrika/LinuxStorage/Inputs_for_branch_pred/benchmark/bin/MST_opt -o "/media/chandrika/LinuxStorage/Inputs_for_branch_pred/benchmark/inputs/rand-weighted-small.graph"

./build/X86/gem5.opt configs/example/se.py --cpu-type=DerivO3CPU --caches --l2cache --bp-type=TournamentBP8KB -c /media/chandrika/LinuxStorage/Inputs_for_branch_pred/benchmark/bin/queens_opt -o "-c 11"


2) For 32KB Configuration

(i) We have three inputs of BFS, MST and Queens.

./build/X86/gem5.opt configs/example/se.py --cpu-type=DerivO3CPU --caches --l2cache --bp-type=TournamentBP32KB -c /media/chandrika/LinuxStorage/Inputs_for_branch_pred/benchmark/bin/BFS_opt -o "/media/chandrika/LinuxStorage/Inputs_for_branch_pred/benchmark/inputs/R10k.graph"

./build/X86/gem5.opt configs/example/se.py --cpu-type=DerivO3CPU --caches --l2cache --bp-type=TournamentBP32KB -c /media/chandrika/LinuxStorage/Inputs_for_branch_pred/benchmark/bin/MST_opt -o "/media/chandrika/LinuxStorage/Inputs_for_branch_pred/benchmark/inputs/rand-weighted-small.graph"

./build/X86/gem5.opt configs/example/se.py --cpu-type=DerivO3CPU --caches --l2cache --bp-type=TournamentBP32KB -c /media/chandrika/LinuxStorage/Inputs_for_branch_pred/benchmark/bin/queens_opt -o "-c 11"

--------------------------------------------------------------------------------------------------------------------------------------

For GDAC Branch prediction :
 
1) For 8KB Configuration
(i) We have three inputs of BFS, MST and Queens.

./build/X86/gem5.opt configs/example/se.py --cpu-type=DerivO3CPU --caches --l2cache --bp-type=GDacBP8KB -c /media/chandrika/LinuxStorage/Inputs_for_branch_pred/benchmark/bin/BFS_opt -o "/media/chandrika/LinuxStorage/Inputs_for_branch_pred/benchmark/inputs/R10k.graph"

./build/X86/gem5.opt configs/example/se.py --cpu-type=DerivO3CPU --caches --l2cache --bp-type=GDacBP8KB -c /media/chandrika/LinuxStorage/Inputs_for_branch_pred/benchmark/bin/MST_opt -o "/media/chandrika/LinuxStorage/Inputs_for_branch_pred/benchmark/inputs/rand-weighted-small.graph"

./build/X86/gem5.opt configs/example/se.py --cpu-type=DerivO3CPU --caches --l2cache --bp-type=GDacBP8KB -c /media/chandrika/LinuxStorage/Inputs_for_branch_pred/benchmark/bin/queens_opt -o "-c 11"


2) For 32KB Configuration

(i) We have three inputs of BFS, MST and Queens.

./build/X86/gem5.opt configs/example/se.py --cpu-type=DerivO3CPU --caches --l2cache --bp-type=GDacBP32KB -c /media/chandrika/LinuxStorage/Inputs_for_branch_pred/benchmark/bin/BFS_opt -o "/media/chandrika/LinuxStorage/Inputs_for_branch_pred/benchmark/inputs/R10k.graph"

./build/X86/gem5.opt configs/example/se.py --cpu-type=DerivO3CPU --caches --l2cache --bp-type=GDacBP32KB -c /media/chandrika/LinuxStorage/Inputs_for_branch_pred/benchmark/bin/MST_opt -o "/media/chandrika/LinuxStorage/Inputs_for_branch_pred/benchmark/inputs/rand-weighted-small.graph"

./build/X86/gem5.opt configs/example/se.py --cpu-type=DerivO3CPU --caches --l2cache --bp-type=GDacBP32KBv -c /media/chandrika/LinuxStorage/Inputs_for_branch_pred/benchmark/bin/queens_opt -o "-c 11"

-------------------------------------------------------------------------------------------------------------------------------------------










