Author : Chandrika C.S ( 1215321133)
In order to run the simulations, kindly apply the patch named "latestPatch.patch" as follows. 

cd gem5-master/src/mem/cache/replacement_policies
patch -p5 < ./latestPatch.patch

Now , that all the source files are added. Now build the gem5 with the following command. 

​scons -j4 build/X86/gem5.opt

After the gem5.opt is generated. Now start the simulations.

We are going to run all the three replacement policies with various specifications of L2 Cache size , L2 Replacement policy. Input program and input data .

Stats.txt, config.ini and config.json are generated. Look for l2.overall.cachemissrate value and check if the proper replacement policy is in effect by opening config.ini/config.json. You will find the name of the policy and cache size mentioned. Hence we can verify the effect.
Now start Tabulating the values. 
Run the following commands for values.

Mentioning the various simulation commands that were used during the simulation for various policies of LRU, SSRIP and SHIP. 
Kindly change the variables of PATH, POLLICY, CACHE SIZE, INPUT PROG and INPUT Data size in order to run the simulations successfully.
Please go through the project report for further explanation on Simulation commands.



LRU:
./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=256kB --l2_assoc=16 -c /media/chandrika/LinuxStorage/benchmark/bin/MST_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/MST_randLocalGraph_WE_5_100000"

SRRIP:
./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=256kB --l2_assoc=16 --l2_rpp="SRRIPRP()" -c /media/chandrika/LinuxStorage/benchmark/bin/BFS_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/BFS_randLocalGraph_J_5_120000"

SHIP:
./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=256kB --l2_assoc=16 --l2_rpp="SHIPRP()" -c /media/Nishant/LinuxStorage/benchmark/bin/BFS_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/BFS_rMatGraph_J_5_90000"






GENERIC COMMANDS CONTEXT for BFS_OPT AND MST_OPT 
Kindly change the variables of PATH, POLLICY, CACHE SIZE, INPUT PROG and INPUT Data size in order to run the simulations successfully.
 

LRU - 256KB

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=256kB --l2_assoc=16 -c /media/chandrika/LinuxStorage/benchmark/bin/BFS_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/BFS_randLocalGraph_J_5_120000"

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=256kB --l2_assoc=16 -c /media/chandrika/LinuxStorage/benchmark/bin/BFS_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/BFS_rMatGraph_J_5_90000"

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=256kB --l2_assoc=16 -c /media/chandrika/LinuxStorage/benchmark/bin/MST_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/MST_randLocalGraph_WE_5_100000"

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=256kB --l2_assoc=16 -c /media/chandrika/LinuxStorage/benchmark/bin/MST_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/MST_rMatGraph_WE_5_35000"


LRU - 1MB


./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=1MB --l2_assoc=16 -c /media/chandrika/LinuxStorage/benchmark/bin/BFS_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/BFS_randLocalGraph_J_5_120000"

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=1MB --l2_assoc=16  -c /media/chandrika/LinuxStorage/benchmark/bin/BFS_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/BFS_rMatGraph_J_5_90000"

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=1MB --l2_assoc=16 -c /media/chandrika/LinuxStorage/benchmark/bin/MST_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/MST_randLocalGraph_WE_5_100000"

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=1MB --l2_assoc=16  -c /media/chandrika/LinuxStorage/benchmark/bin/MST_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/MST_rMatGraph_WE_5_35000"


LRU - 4MB

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=4MB --l2_assoc=16 -c /media/chandrika/LinuxStorage/benchmark/bin/BFS_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/BFS_randLocalGraph_J_5_120000"

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=4MB --l2_assoc=16 -c /media/chandrika/LinuxStorage/benchmark/bin/BFS_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/BFS_rMatGraph_J_5_90000"

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=4MB --l2_assoc=16 -c /media/chandrika/LinuxStorage/benchmark/bin/MST_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/MST_randLocalGraph_WE_5_100000"

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=4MB --l2_assoc=16 -c /media/chandrika/LinuxStorage/benchmark/bin/MST_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/MST_rMatGraph_WE_5_35000"




SRRIP - 256KB 

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=256kB --l2_assoc=16 --l2_rpp="SRRIPRP()" -c /media/chandrika/LinuxStorage/benchmark/bin/BFS_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/BFS_randLocalGraph_J_5_120000"

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=256kB --l2_assoc=16 --l2_rpp="SRRIPRP()" -c /media/chandrika/LinuxStorage/benchmark/bin/BFS_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/BFS_rMatGraph_J_5_90000"

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=256kB --l2_assoc=16 --l2_rpp="SRRIPRP()" -c /media/chandrika/LinuxStorage/benchmark/bin/MST_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/MST_randLocalGraph_WE_5_100000"

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=256kB --l2_assoc=16 --l2_rpp="SRRIPRP()" -c /media/chandrika/LinuxStorage/benchmark/bin/MST_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/MST_rMatGraph_WE_5_35000"





SRRIP - 1MB



./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=1MB --l2_assoc=16 --l2_rpp="SRRIPRP()" -c /media/chandrika/LinuxStorage/benchmark/bin/BFS_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/BFS_randLocalGraph_J_5_120000"

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=1MB --l2_assoc=16 --l2_rpp="SRRIPRP()" -c /media/chandrika/LinuxStorage/benchmark/bin/BFS_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/BFS_rMatGraph_J_5_90000"

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=1MB --l2_assoc=16 --l2_rpp="SRRIPRP()" -c /media/chandrika/LinuxStorage/benchmark/bin/MST_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/MST_randLocalGraph_WE_5_100000"

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=1MB --l2_assoc=16 --l2_rpp="SRRIPRP()" -c /media/chandrika/LinuxStorage/benchmark/bin/MST_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/MST_rMatGraph_WE_5_35000"


SRRIP - 4MB

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=4MB --l2_assoc=16 --l2_rpp="SRRIPRP()" -c /media/chandrika/LinuxStorage/benchmark/bin/BFS_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/BFS_randLocalGraph_J_5_120000"

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=4MB --l2_assoc=16 --l2_rpp="SRRIPRP()" -c /media/chandrika/LinuxStorage/benchmark/bin/BFS_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/BFS_rMatGraph_J_5_90000"

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=4MB --l2_assoc=16 --l2_rpp="SRRIPRP()" -c /media/chandrika/LinuxStorage/benchmark/bin/MST_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/MST_randLocalGraph_WE_5_100000"

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=4MB --l2_assoc=16 --l2_rpp="SRRIPRP()" -c /media/chandrika/LinuxStorage/benchmark/bin/MST_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/MST_rMatGraph_WE_5_35000"


SHIP - 256KB 

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=256kB --l2_assoc=16 --l2_rpp="SHIPRP()" -c /media/chandrika/LinuxStorage/benchmark/bin/BFS_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/BFS_randLocalGraph_J_5_120000"

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=256kB --l2_assoc=16 --l2_rpp="SHIPRP()" -c /media/chandrika/LinuxStorage/benchmark/bin/BFS_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/BFS_rMatGraph_J_5_90000"

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=256kB --l2_assoc=16 --l2_rpp="SHIPRP()" -c /media/chandrika/LinuxStorage/benchmark/bin/MST_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/MST_randLocalGraph_WE_5_100000"

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=256kB --l2_assoc=16 --l2_rpp="SHIPRP()" -c /media/chandrika/LinuxStorage/benchmark/bin/MST_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/MST_rMatGraph_WE_5_35000"





SHIPRP - 1MB



./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=1MB --l2_assoc=16 --l2_rpp="SHIPRP()" -c /media/chandrika/LinuxStorage/benchmark/bin/BFS_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/BFS_randLocalGraph_J_5_120000"

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=1MB --l2_assoc=16 --l2_rpp="SHIPRP()" -c /media/chandrika/LinuxStorage/benchmark/bin/BFS_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/BFS_rMatGraph_J_5_90000"

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=1MB --l2_assoc=16 --l2_rpp="SHIPRP()" -c /media/chandrika/LinuxStorage/benchmark/bin/MST_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/MST_randLocalGraph_WE_5_100000"

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=1MB --l2_assoc=16 --l2_rpp="SHIPRP()" -c /media/chandrika/LinuxStorage/benchmark/bin/MST_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/MST_rMatGraph_WE_5_35000"


SHIPRP - 4MB

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=4MB --l2_assoc=16 --l2_rpp="SHIPRP()" -c /media/chandrika/LinuxStorage/benchmark/bin/BFS_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/BFS_randLocalGraph_J_5_120000"

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=4MB --l2_assoc=16 --l2_rpp="SHIPRP()" -c /media/chandrika/LinuxStorage/benchmark/bin/BFS_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/BFS_rMatGraph_J_5_90000"

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=4MB --l2_assoc=16 --l2_rpp="SHIPRP()" -c /media/chandrika/LinuxStorage/benchmark/bin/MST_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/MST_randLocalGraph_WE_5_100000"

./build/X86/gem5.opt configs/example/se.py --cpu-type=AtomicSimpleCPU --caches --l1i_size=32kB --l1d_size=32kB --l2cache --l2_size=4MB --l2_assoc=16 --l2_rpp="SHIPRP()" -c /media/chandrika/LinuxStorage/benchmark/bin/MST_opt -o "/media/chandrika/LinuxStorage/benchmark_assign2/MST_rMatGraph_WE_5_35000"







