README TEXT FILE :
Author : C.S.Chandrika 
ASU ID : 1215321133 

Steps to execute the code.

1) Open the source folder containing the files of main.cpp and matrix_mul.cl. Open the terminal and type in the command "make all"

2) In order to execute the values for various matrix sizes and various tile sizes, configure that information in the makefile. 
You can edit the makefile and enter the values you wish to test for in the makefile in the first line.

3) In order to delete the generated .o and .exe files,just type "make clean" command. 

3) In order to test for tiled kernel function, kindly go to the code on line number 83 and replace the program function name with "matrix_mul_tile" and set the size of matrix and tile size in the makefile and run the program to generate the values. 
	For the normal / naive multiplication, kindly repeat the procedure and instead replace the program function name with "matrix_mul" and set the size of matrix and tile size in the makefile and run the program to generate the values. 

4)For Naive Multiplication, (i.e. Normal Kernel multiplication) , the value of tile passed doesn’t matter . 	
	Setting the tile size to be any value wouldnt affect the Naive Baye’s multiplication as long as we are setting the program string to “matrix_mul” .


4) Thus you can generate the various values . 
